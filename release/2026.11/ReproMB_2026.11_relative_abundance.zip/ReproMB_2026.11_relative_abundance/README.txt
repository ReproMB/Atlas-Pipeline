ReproMB Atlas - genus relative abundance (%)
Dataset version 2026.11, generated 2026-11-12 11:44 UTC
https://repromb.ugr.es/repromb/

Files (samples in rows, genera in columns, most abundant genus first)
  relative_abundance_Vagina.csv          8,296 samples, 385 genera
  relative_abundance_Cervix.csv          1,115 samples, 258 genera
  relative_abundance_Cervicovaginal.csv  32 samples, 41 genera
  relative_abundance_Endometrium.csv     2,197 samples, 779 genera
  relative_abundance_Gut.csv             1,541 samples, 263 genera
  relative_abundance_Rectum.csv          177 samples, 180 genera
  taxa.csv                               SILVA lineage and NCBI Taxonomy ID of each genus

The sample metadata are in the metadata download; join the files by sample_id.

Relative abundance (%) = reads of the genus / reads assigned to any genus in the sample
(genus_reads in the metadata) x 100. Genera that are rare in a site (mean below 0.01% and
never above 1% in any sample) were dropped from that site, so a sample can add up to
slightly less than 100%.

Lactobacillus is split into the L. crispatus, L. gasseri and L. jensenii groups, L. iners
and Lactobacillus (unresolved); together they make up total Lactobacillus. Mitochondria
and chloroplasts were removed. Genera on the contaminant watchlist are included; the web
can hide them with Filter contamination.

The CSV files are UTF-8 and comma-separated, with a dot as decimal separator. Empty cells
are missing values. In Excel, open them with Data > From Text/CSV.

License
The curated compilation (harmonised abundance tables and metadata) is released under CC BY
4.0 (https://creativecommons.org/licenses/by/4.0/). The original datasets remain under the
terms of their source repositories.

How to cite
ReproMB - Reproductive tract microbiome atlas. Repro-UGR and AI-Biomed research groups,
University of Granada. Dataset version 2026.11. https://repromb.ugr.es/repromb/
Please also cite the original studies whose samples you use. They are listed with their
DOIs at https://repromb.ugr.es/repromb/data-sources
