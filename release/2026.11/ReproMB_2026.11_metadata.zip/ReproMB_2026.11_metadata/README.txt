ReproMB Atlas - sample metadata
Dataset version 2026.11, generated 2026-11-12 11:44 UTC
https://repromb.ugr.es/repromb/

metadata.csv has one row per sample: 13,358 samples from 6 body sites.

Columns
  sample_id             sample identifier, shared with the abundance files
  site                  body site
  study                 accession of the source study (BioProject or equivalent)
  condition             harmonised condition; Control = control group of the study
  age, bmi              years and kg/m2, as reported by each study
  ethnicity             as reported by each study
  menstrual_cycle       phase of the cycle at sampling, as reported by each study
  region_16s            sequenced region of the 16S rRNA gene
  platform, instrument  as reported in the source repository (most common in the study)
  genus_reads           reads assigned to any genus, before rare genera were dropped

The CSV files are UTF-8 and comma-separated, with a dot as decimal separator. Empty cells
are missing values. In Excel, open them with Data > From Text/CSV.

License
The curated compilation (harmonised abundance tables and metadata) is released under CC BY
4.0 (https://creativecommons.org/licenses/by/4.0/). The original datasets remain under the
terms of their source repositories.

How to cite
ReproMB - Reproductive tract microbiome atlas. Repro-UGR and AI-Biomed research groups,
University of Granada. Dataset version 2026.11. https://repromb.ugr.es/repromb/
Please also cite the original studies whose samples you use. They are listed with their
DOIs at https://repromb.ugr.es/repromb/data-sources
