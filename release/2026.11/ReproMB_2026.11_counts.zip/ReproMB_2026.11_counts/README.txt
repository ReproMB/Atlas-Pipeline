ReproMB Atlas - genus read counts
Dataset version 2026.11, generated 2026-11-12 11:44 UTC
https://repromb.ugr.es/repromb/

Files (samples in rows, genera in columns, most abundant genus first)
  counts_Vagina.csv          8,296 samples, 385 genera
  counts_Cervix.csv          1,115 samples, 258 genera
  counts_Cervicovaginal.csv  32 samples, 41 genera
  counts_Endometrium.csv     2,197 samples, 779 genera
  counts_Gut.csv             1,541 samples, 263 genera
  counts_Rectum.csv          177 samples, 180 genera
  taxa.csv                   SILVA lineage and NCBI Taxonomy ID of each genus

The sample metadata are in the metadata download; join the files by sample_id.

Counts are the reads assigned to each genus after denoising (DADA2, or Deblur for datasets
with synthetic quality scores) and classification against SILVA 138.2. genus_reads is the
sample total before rare genera were dropped. Genera that are rare in a site (mean below
0.01% and never above 1% in any sample) were dropped from that site.

Lactobacillus is split into the L. crispatus, L. gasseri and L. jensenii groups, L. iners
and Lactobacillus (unresolved); together they make up total Lactobacillus. Mitochondria
and chloroplasts were removed. Genera on the contaminant watchlist are included; the web
can hide them with Filter contamination.

The CSV files are UTF-8 and comma-separated, with a dot as decimal separator. Empty cells
are missing values. In Excel, open them with Data > From Text/CSV.

License
The curated compilation (harmonised abundance tables and metadata) is released under CC BY
4.0 (https://creativecommons.org/licenses/by/4.0/). The original datasets remain under the
terms of their source repositories.

How to cite
ReproMB - Reproductive tract microbiome atlas. Repro-UGR and AI-Biomed research groups,
University of Granada. Dataset version 2026.11. https://repromb.ugr.es/repromb/
Please also cite the original studies whose samples you use. They are listed with their
DOIs at https://repromb.ugr.es/repromb/data-sources
